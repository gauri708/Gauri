# Electricity Connection Or Billing System
# Console Based application (Core Java With MYSQL)

# Adding screenshots
# Home Options
![home ](https://github.com/vivekgithub1997/Electricity-Billing-System/assets/61921329/c43bf57b-63d3-42b5-8e20-9d56f36b51c3)
# Registration ADMIN ( same as USER registration) 
![ebs registration](https://github.com/vivekgithub1997/Electricity-Billing-System/assets/61921329/d9d57618-0cce-4ff6-9f50-960f21a45799)
# Now User Login
![user-login](https://github.com/vivekgithub1997/Electricity-Billing-System/assets/61921329/f74f0537-ac06-4c79-9b5b-d242bd7da340)
# UserDashboard :: Options
 # 1- Request For New Connection
![send new request user](https://github.com/vivekgithub1997/Electricity-Billing-System/assets/61921329/e63d730f-a649-4eb1-b24d-94e1939d62f9)
# Login Admin(Failed)
![login failed](https://github.com/vivekgithub1997/Electricity-Billing-System/assets/61921329/8e2d9777-7b7a-40a3-8412-4dc1e1d53866)
# Login Admin(Success) Admin Dashboard :: Options
![login](https://github.com/vivekgithub1997/Electricity-Billing-System/assets/61921329/fff6649a-023a-4b4c-9075-6cb5300e8a77)
# 1- Show All Request For New Connection
![admin check new request for connection](https://github.com/vivekgithub1997/Electricity-Billing-System/assets/61921329/e6d3b043-fec0-4f8d-ba2f-4cfdc5d964cb)
# 2- Accept The Connection Request
![accept connection request](https://github.com/vivekgithub1997/Electricity-Billing-System/assets/61921329/7c2e50ba-b0eb-426f-9897-feafe550e3cd)
# 3- Show All Connections
![all connection details](https://github.com/vivekgithub1997/Electricity-Billing-System/assets/61921329/6df8b65a-226a-421b-82f0-c8b6c43659c2)
# 4- Generate Bill
![admin bill generate to user specific user account ](https://github.com/vivekgithub1997/Electricity-Billing-System/assets/61921329/69cd7a6a-71b5-4b14-98c6-7c495d50f83b)
# UserDashboard :: Options
 # 2- SHOW CONNECTION DETAILS
![user connection details](https://github.com/vivekgithub1997/Electricity-Billing-System/assets/61921329/673b2d55-97a5-40ad-98c4-c01c38495757)
 # 3- Show Bill
 ![user show bill month of ](https://github.com/vivekgithub1997/Electricity-Billing-System/assets/61921329/a2cb97e1-4269-44b4-88ab-13067d7e1ebc)
# Logout 
![logout](https://github.com/vivekgithub1997/Electricity-Billing-System/assets/61921329/3c8bbdfb-5b86-4c3a-8759-9433c5f33364)
